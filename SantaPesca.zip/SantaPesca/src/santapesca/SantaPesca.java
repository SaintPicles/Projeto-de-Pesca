/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package santapesca;

import javax.swing.JOptionPane;

/**
 *
 * @author lucca.bcdomingues
 */
public class SantaPesca {
     
     public static void travar(){
         for (int i = 0; i < 3; i++) {
             JOptionPane.showMessageDialog(null,"Pesca");
         
             
         }
   
     }
     public static void travar2(){
        
             JOptionPane.showMessageDialog(null,"Continue na Pesca");
             
         
     }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        travar();
        travar2();
        
        
    }
    
}
