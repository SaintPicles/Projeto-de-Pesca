<?php
require_once '../config.php';

redirecionarSeNaoAdmin();

// Estatísticas
$sql_total_pedidos = "SELECT COUNT(*) as total FROM orders";
$total_pedidos = $conn->query($sql_total_pedidos)->fetch_assoc()['total'];

$sql_total_vendas = "SELECT SUM(total) as total FROM orders WHERE status IN ('Pago', 'Enviado', 'Entregue')";
$result_vendas = $conn->query($sql_total_vendas)->fetch_assoc();
$total_vendas = $result_vendas['total'] ?? 0;

$sql_total_produtos = "SELECT COUNT(*) as total FROM products";
$total_produtos = $conn->query($sql_total_produtos)->fetch_assoc()['total'];

$sql_total_clientes = "SELECT COUNT(*) as total FROM users WHERE tipo = 'cliente'";
$total_clientes = $conn->query($sql_total_clientes)->fetch_assoc()['total'];

$sql_pedidos_pendentes = "SELECT COUNT(*) as total FROM orders WHERE status = 'Pendente'";
$pedidos_pendentes = $conn->query($sql_pedidos_pendentes)->fetch_assoc()['total'];

$sql_estoque_baixo = "SELECT COUNT(*) as total FROM products WHERE estoque <= 5 AND estoque > 0";
$estoque_baixo = $conn->query($sql_estoque_baixo)->fetch_assoc()['total'];

// Últimos pedidos
$sql_ultimos_pedidos = "SELECT o.*, u.nome as cliente_nome FROM orders o 
                        INNER JOIN users u ON o.cliente_id = u.id 
                        ORDER BY o.data_criacao DESC LIMIT 5";
$ultimos_pedidos = $conn->query($sql_ultimos_pedidos);

// Produtos mais vendidos
$sql_mais_vendidos = "SELECT p.nome, p.imagem, SUM(oi.quantidade) as total_vendido 
                      FROM order_items oi 
                      INNER JOIN products p ON oi.produto_id = p.id 
                      GROUP BY oi.produto_id 
                      ORDER BY total_vendido DESC LIMIT 5";
$mais_vendidos = $conn->query($sql_mais_vendidos);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            color: white !important;
        }
        
        .nav-link {
            color: white !important;
            font-weight: 500;
        }
        
        .nav-link:hover {
            color: var(--ps-light-blue) !important;
        }
        
        .admin-container {
            padding: 30px 0;
        }
        
        .stat-card {
            background: rgba(31, 31, 31, 0.9);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--ps-light-blue);
            box-shadow: 0 10px 30px rgba(0, 112, 204, 0.4);
        }
        
        .stat-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            margin: 10px 0;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .content-card {
            background: rgba(31, 31, 31, 0.9);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .table {
            color: white;
        }
        
        .table thead {
            background: rgba(0, 112, 204, 0.3);
            border-bottom: 2px solid var(--ps-light-blue);
        }
        
        .table tbody tr {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .table tbody tr:hover {
            background: rgba(0, 112, 204, 0.2);
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 25px;
            transition: all 0.3s;
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            color: white;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-cog"></i> ADMIN GAMEVAULT
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php"><i class="fas fa-gamepad"></i> Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pedidos.php"><i class="fas fa-shopping-cart"></i> Pedidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="categorias.php"><i class="fas fa-tags"></i> Categorias</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cupons.php"><i class="fas fa-ticket-alt"></i> Cupons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php"><i class="fas fa-store"></i> Ver Loja</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid admin-container">
        <h1 style="font-size: 2.5rem; font-weight: 800; margin-bottom: 30px;">
            <i class="fas fa-chart-line"></i> DASHBOARD
        </h1>

        <!-- Estatísticas -->
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-icon" style="color: #007bff;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value" style="color: #007bff;">
                        <?php echo $total_pedidos; ?>
                    </div>
                    <div class="stat-label">Total de Pedidos</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-icon" style="color: #28a745;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-value" style="color: #28a745;">
                        <?php echo formatarPreco($total_vendas); ?>
                    </div>
                    <div class="stat-label">Total em Vendas</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-icon" style="color: var(--ps-light-blue);">
                        <i class="fas fa-gamepad"></i>
                    </div>
                    <div class="stat-value" style="color: var(--ps-light-blue);">
                        <?php echo $total_produtos; ?>
                    </div>
                    <div class="stat-label">Produtos Cadastrados</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-icon" style="color: #ffc107;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value" style="color: #ffc107;">
                        <?php echo $total_clientes; ?>
                    </div>
                    <div class="stat-label">Clientes Cadastrados</div>
                </div>
            </div>
        </div>

        <!-- Alertas -->
        <div class="row">
            <?php if($pedidos_pendentes > 0): ?>
                <div class="col-md-6">
                    <div class="alert alert-warning" style="background: rgba(255, 193, 7, 0.2); border: 2px solid #ffc107; color: #ffc107;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong><?php echo $pedidos_pendentes; ?></strong> pedido(s) aguardando confirmação de pagamento.
                        <a href="pedidos.php" class="float-end text-white">Ver pedidos »</a>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if($estoque_baixo > 0): ?>
                <div class="col-md-6">
                    <div class="alert alert-danger" style="background: rgba(220, 53, 69, 0.2); border: 2px solid #dc3545; color: #dc3545;">
                        <i class="fas fa-box"></i>
                        <strong><?php echo $estoque_baixo; ?></strong> produto(s) com estoque baixo.
                        <a href="produtos.php" class="float-end text-white">Ver produtos »</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <!-- Últimos Pedidos -->
            <div class="col-md-7">
                <div class="content-card">
                    <h3 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                        <i class="fas fa-clock"></i> ÚLTIMOS PEDIDOS
                    </h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Pedido</th>
                                    <th>Cliente</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($pedido = $ultimos_pedidos->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                        <td><?php echo htmlspecialchars($pedido['cliente_nome']); ?></td>
                                        <td><?php echo formatarPreco($pedido['total']); ?></td>
                                        <td>
                                            <span class="status-badge" style="background: rgba(255, 193, 7, 0.3); color: #ffc107;">
                                                <?php echo $pedido['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($pedido['data_criacao'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-3">
                        <a href="pedidos.php" class="btn btn-ps5">
                            <i class="fas fa-list"></i> Ver Todos os Pedidos
                        </a>
                    </div>
                </div>
            </div>

            <!-- Produtos Mais Vendidos -->
            <div class="col-md-5">
                <div class="content-card">
                    <h3 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                        <i class="fas fa-trophy"></i> MAIS VENDIDOS
                    </h3>
                    <?php while($produto = $mais_vendidos->fetch_assoc()): ?>
                        <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: rgba(0, 67, 156, 0.1); border-radius: 10px; margin-bottom: 10px;">
                            <img src="../uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" 
                                 style="width: 50px; height: 50px; border-radius: 5px; object-fit: cover;"
                                 onerror="this.src='https://via.placeholder.com/50x50/1a1a2e/0070CC'">
                            <div style="flex: 1;">
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($produto['nome']); ?></div>
                                <div style="color: var(--ps-light-blue); font-size: 0.9rem;">
                                    <i class="fas fa-shopping-cart"></i> <?php echo $produto['total_vendido']; ?> vendas
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>