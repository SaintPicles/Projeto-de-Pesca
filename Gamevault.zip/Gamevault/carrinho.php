<?php
require_once 'config.php';

// Processar ações do carrinho
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['atualizar_quantidade'])) {
        foreach ($_POST['quantidade'] as $produto_id => $quantidade) {
            atualizarQuantidadeCarrinho($produto_id, intval($quantidade));
        }
        $_SESSION['mensagem_sucesso'] = 'Carrinho atualizado!';
        header('Location: carrinho.php');
        exit();
    }
    
    if (isset($_POST['remover'])) {
        $produto_id = intval($_POST['remover']);
        removerDoCarrinho($produto_id);
        $_SESSION['mensagem_sucesso'] = 'Produto removido do carrinho!';
        header('Location: carrinho.php');
        exit();
    }
    
    if (isset($_POST['limpar_carrinho'])) {
        $_SESSION['carrinho'] = array();
        $_SESSION['mensagem_sucesso'] = 'Carrinho limpo!';
        header('Location: carrinho.php');
        exit();
    }
}

// Buscar produtos do carrinho
$produtos_carrinho = array();
$subtotal = 0;

if (!empty($_SESSION['carrinho'])) {
    $ids = array_keys($_SESSION['carrinho']);
    $ids_str = implode(',', $ids);
    
    $sql = "SELECT * FROM products WHERE id IN ($ids_str)";
    $result = $conn->query($sql);
    
    while ($produto = $result->fetch_assoc()) {
        $produto['quantidade_carrinho'] = $_SESSION['carrinho'][$produto['id']];
        $produto['subtotal_item'] = $produto['preco'] * $produto['quantidade_carrinho'];
        $subtotal += $produto['subtotal_item'];
        $produtos_carrinho[] = $produto;
    }
}

$frete = 15.00;
$total = $subtotal + $frete;

// Aplicar cupom se existir
$desconto = 0;
$cupom_codigo = '';
if (isset($_SESSION['cupom_aplicado'])) {
    $cupom_codigo = $_SESSION['cupom_aplicado']['codigo'];
    $desconto = $_SESSION['cupom_aplicado']['desconto'];
    
    if ($_SESSION['cupom_aplicado']['tipo'] === 'percentual') {
        $desconto = $subtotal * ($desconto / 100);
    }
    
    $total -= $desconto;
}

// Processar aplicação de cupom
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aplicar_cupom'])) {
    $codigo = limparInput($_POST['codigo_cupom']);
    
    $sql = "SELECT * FROM cupons WHERE codigo = '$codigo' AND ativo = TRUE AND (validade IS NULL OR validade >= CURDATE())";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $cupom = $result->fetch_assoc();
        $_SESSION['cupom_aplicado'] = $cupom;
        $_SESSION['mensagem_sucesso'] = 'Cupom aplicado com sucesso!';
    } else {
        $_SESSION['mensagem_erro'] = 'Cupom inválido ou expirado!';
    }
    
    header('Location: carrinho.php');
    exit();
}

// Remover cupom
if (isset($_GET['remover_cupom'])) {
    unset($_SESSION['cupom_aplicado']);
    header('Location: carrinho.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
            --ps-dark: #000000;
            --ps-gray: #1F1F1F;
            --ps-white: #FFFFFF;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: var(--ps-white);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
            box-shadow: 0 4px 30px rgba(0, 112, 204, 0.3);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--ps-white) !important;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .navbar-brand i {
            color: var(--ps-light-blue);
        }
        
        .nav-link {
            color: var(--ps-white) !important;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--ps-light-blue) !important;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 25px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
        
        .page-header {
            text-align: center;
            padding: 50px 0 30px;
        }
        
        .page-header h1 {
            font-size: 3rem;
            font-weight: 800;
            text-transform: uppercase;
            text-shadow: 0 0 30px rgba(0, 112, 204, 0.8);
        }
        
        .cart-container {
            background: rgba(31, 31, 31, 0.9);
            border-radius: 20px;
            padding: 30px;
            margin: 30px 0;
            border: 2px solid var(--ps-blue);
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.3);
        }
        
        .cart-item {
            background: rgba(0, 67, 156, 0.1);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .cart-item:hover {
            border-color: var(--ps-light-blue);
            box-shadow: 0 5px 20px rgba(0, 112, 204, 0.3);
        }
        
        .cart-item-image {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        
        .cart-item-image img {
            max-width: 100%;
            max-height: 100%;
        }
        
        .quantity-input {
            width: 80px;
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 8px;
            border-radius: 8px;
            font-weight: 600;
        }
        
        .summary-box {
            background: rgba(0, 67, 156, 0.2);
            border: 2px solid var(--ps-light-blue);
            border-radius: 15px;
            padding: 25px;
            position: sticky;
            top: 100px;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .summary-total {
            font-size: 2rem;
            font-weight: 800;
            color: var(--ps-light-blue);
            padding-top: 15px;
            display: flex;
            justify-content: space-between;
        }
        
        .empty-cart {
            text-align: center;
            padding: 80px 20px;
        }
        
        .empty-cart i {
            font-size: 8rem;
            color: var(--ps-light-blue);
            opacity: 0.5;
            margin-bottom: 30px;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 2px solid #28a745;
            color: #28a745;
            border-radius: 15px;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 2px solid #dc3545;
            color: #dc3545;
            border-radius: 15px;
        }
        
        .cupom-box {
            background: rgba(0, 67, 156, 0.2);
            border: 2px dashed var(--ps-light-blue);
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .cupom-badge {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            display: inline-block;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="carrinho.php">
                            <i class="fas fa-shopping-cart"></i> Carrinho
                        </a>
                    </li>
                    <?php if(isLogado()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="minha-conta.php"><i class="fas fa-user"></i> Minha Conta</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-shopping-cart"></i> MEU CARRINHO</h1>
        </div>

        <?php if(isset($_SESSION['mensagem_sucesso'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['mensagem_sucesso']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['mensagem_sucesso']); ?>
        <?php endif; ?>

        <?php if(isset($_SESSION['mensagem_erro'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['mensagem_erro']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['mensagem_erro']); ?>
        <?php endif; ?>

        <?php if (empty($produtos_carrinho)): ?>
            <!-- Carrinho Vazio -->
            <div class="cart-container">
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <h2>Seu carrinho está vazio</h2>
                    <p class="lead">Adicione jogos incríveis ao seu carrinho e comece sua jornada!</p>
                    <a href="index.php" class="btn btn-ps5 btn-lg mt-3">
                        <i class="fas fa-gamepad"></i> EXPLORAR CATÁLOGO
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Carrinho com Produtos -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="cart-container">
                        <form method="POST" id="formCarrinho">
                            <?php foreach ($produtos_carrinho as $produto): ?>
                                <div class="cart-item">
                                    <div class="row align-items-center">
                                        <div class="col-md-2">
                                            <div class="cart-item-image">
                                                <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" 
                                                     alt="<?php echo htmlspecialchars($produto['nome']); ?>"
                                                     onerror="this.src='https://via.placeholder.com/120x120/1a1a2e/0070CC?text=Game'">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <h5 style="color: white; font-weight: 600;">
                                                <?php echo htmlspecialchars($produto['nome']); ?>
                                            </h5>
                                            <p style="color: var(--ps-light-blue); margin: 0;">
                                                Preço unitário: <?php echo formatarPreco($produto['preco']); ?>
                                            </p>
                                        </div>
                                        <div class="col-md-2 text-center">
                                            <label style="font-size: 0.9rem; display: block; margin-bottom: 5px;">Quantidade:</label>
                                            <input type="number" name="quantidade[<?php echo $produto['id']; ?>]" 
                                                   value="<?php echo $produto['quantidade_carrinho']; ?>" 
                                                   min="1" max="<?php echo $produto['estoque']; ?>" 
                                                   class="quantity-input"
                                                   onchange="document.getElementById('formCarrinho').submit()">
                                        </div>
                                        <div class="col-md-3 text-center">
                                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--ps-light-blue);">
                                                <?php echo formatarPreco($produto['subtotal_item']); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-1 text-center">
                                            <button type="submit" name="remover" value="<?php echo $produto['id']; ?>" 
                                                    class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Deseja remover este item?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <input type="hidden" name="atualizar_quantidade" value="1">
                        </form>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="index.php" class="btn btn-outline-light">
                                <i class="fas fa-arrow-left"></i> Continuar Comprando
                            </a>
                            <form method="POST" style="display: inline;">
                                <button type="submit" name="limpar_carrinho" class="btn btn-outline-danger"
                                        onclick="return confirm('Deseja limpar todo o carrinho?')">
                                    <i class="fas fa-trash-alt"></i> Limpar Carrinho
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Cupom de Desconto -->
                    <div class="cupom-box">
                        <h5><i class="fas fa-ticket-alt"></i> Cupom de Desconto</h5>
                        <?php if(isset($_SESSION['cupom_aplicado'])): ?>
                            <div class="mt-3">
                                <span class="cupom-badge">
                                    <i class="fas fa-check"></i> <?php echo htmlspecialchars($cupom_codigo); ?>
                                </span>
                                <a href="?remover_cupom=1" class="btn btn-sm btn-outline-danger ms-2">
                                    <i class="fas fa-times"></i>
                                </a>
                            </div>
                        <?php else: ?>
                            <form method="POST" class="mt-3">
                                <div class="input-group">
                                    <input type="text" name="codigo_cupom" class="form-control" 
                                           placeholder="Digite o cupom" required
                                           style="background: rgba(255, 255, 255, 0.1); border: 2px solid var(--ps-blue); color: white;">
                                    <button type="submit" name="aplicar_cupom" class="btn btn-ps5">
                                        Aplicar
                                    </button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>

                    <!-- Resumo do Pedido -->
                    <div class="summary-box">
                        <h4 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                            <i class="fas fa-receipt"></i> RESUMO DO PEDIDO
                        </h4>
                        
                        <div class="summary-item">
                            <span>Subtotal:</span>
                            <span><?php echo formatarPreco($subtotal); ?></span>
                        </div>
                        
                        <?php if($desconto > 0): ?>
                            <div class="summary-item" style="color: #28a745;">
                                <span><i class="fas fa-tag"></i> Desconto:</span>
                                <span>- <?php echo formatarPreco($desconto); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="summary-item">
                            <span>Frete:</span>
                            <span><?php echo formatarPreco($frete); ?></span>
                        </div>
                        
                        <div class="summary-total">
                            <span>TOTAL:</span>
                            <span><?php echo formatarPreco($total); ?></span>
                        </div>
                        
                        <div class="d-grid gap-2 mt-4">
                            <a href="checkout.php" class="btn btn-ps5 btn-lg">
                                <i class="fas fa-credit-card"></i> FINALIZAR COMPRA
                            </a>
                        </div>
                        
                        <div class="text-center mt-3" style="font-size: 0.9rem; opacity: 0.8;">
                            <i class="fas fa-lock"></i> Compra 100% segura
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>