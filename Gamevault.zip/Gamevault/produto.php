<?php
require_once 'config.php';

// Verificar se foi passado um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$produto_id = intval($_GET['id']);

// Processar adição ao carrinho
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adicionar_carrinho'])) {
    $quantidade = isset($_POST['quantidade']) ? intval($_POST['quantidade']) : 1;
    
    if ($quantidade > 0) {
        adicionarAoCarrinho($produto_id, $quantidade);
        $_SESSION['mensagem_sucesso'] = 'Produto adicionado ao carrinho!';
        header('Location: produto.php?id=' . $produto_id);
        exit();
    }
}

// Buscar dados do produto
$sql = "SELECT p.*, c.nome as categoria_nome, c.slug as categoria_slug 
        FROM products p 
        INNER JOIN categories c ON p.categoria_id = c.id 
        WHERE p.id = $produto_id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    header('Location: index.php');
    exit();
}

$produto = $result->fetch_assoc();

// Buscar produtos relacionados (mesma categoria)
$sql_relacionados = "SELECT p.*, c.nome as categoria_nome 
                     FROM products p 
                     INNER JOIN categories c ON p.categoria_id = c.id 
                     WHERE p.categoria_id = {$produto['categoria_id']} 
                     AND p.id != $produto_id 
                     ORDER BY RAND() 
                     LIMIT 4";
$relacionados = $conn->query($sql_relacionados);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($produto['nome']); ?> - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
            --ps-dark: #000000;
            --ps-gray: #1F1F1F;
            --ps-white: #FFFFFF;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: var(--ps-white);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
            box-shadow: 0 4px 30px rgba(0, 112, 204, 0.3);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--ps-white) !important;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .navbar-brand i {
            color: var(--ps-light-blue);
        }
        
        .nav-link {
            color: var(--ps-white) !important;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: var(--ps-light-blue) !important;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 25px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
        
        .product-detail-container {
            background: rgba(31, 31, 31, 0.9);
            border-radius: 20px;
            padding: 40px;
            margin: 50px 0;
            border: 2px solid var(--ps-blue);
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.3);
        }
        
        .product-image-main {
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            border-radius: 15px;
            padding: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 400px;
            border: 2px solid var(--ps-blue);
        }
        
        .product-image-main img {
            max-width: 100%;
            max-height: 500px;
            border-radius: 10px;
        }
        
        .product-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 15px;
            color: var(--ps-white);
            text-transform: uppercase;
        }
        
        .product-category-badge {
            display: inline-block;
            background: var(--ps-light-blue);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 600;
            margin-bottom: 20px;
        }
        
        .product-price {
            font-size: 3rem;
            font-weight: 800;
            color: var(--ps-light-blue);
            margin: 20px 0;
            text-shadow: 0 0 20px rgba(0, 112, 204, 0.5);
        }
        
        .product-info-item {
            background: rgba(0, 67, 156, 0.2);
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
            border-left: 4px solid var(--ps-light-blue);
        }
        
        .product-info-item strong {
            color: var(--ps-light-blue);
        }
        
        .quantity-selector {
            display: flex;
            align-items: center;
            gap: 15px;
            margin: 20px 0;
        }
        
        .quantity-selector input {
            width: 80px;
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 10px;
            border-radius: 10px;
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        .quantity-btn {
            background: var(--ps-blue);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .quantity-btn:hover {
            background: var(--ps-light-blue);
            transform: scale(1.1);
        }
        
        .stock-badge {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            margin: 10px 0;
        }
        
        .stock-available {
            background: rgba(40, 167, 69, 0.3);
            color: #28a745;
            border: 2px solid #28a745;
        }
        
        .stock-low {
            background: rgba(255, 193, 7, 0.3);
            color: #ffc107;
            border: 2px solid #ffc107;
        }
        
        .stock-out {
            background: rgba(220, 53, 69, 0.3);
            color: #dc3545;
            border: 2px solid #dc3545;
        }
        
        .product-description {
            background: rgba(0, 67, 156, 0.1);
            padding: 25px;
            border-radius: 15px;
            margin: 30px 0;
            border: 2px solid var(--ps-blue);
        }
        
        .related-products {
            margin-top: 60px;
        }
        
        .product-card {
            background: rgba(31, 31, 31, 0.8);
            border: 2px solid transparent;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
            height: 100%;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
            border-color: var(--ps-light-blue);
            box-shadow: 0 10px 40px rgba(0, 112, 204, 0.5);
        }
        
        .product-card-image {
            height: 200px;
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .product-card-image img {
            max-width: 100%;
            max-height: 100%;
        }
        
        .breadcrumb {
            background: rgba(0, 67, 156, 0.2);
            padding: 15px 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .breadcrumb a {
            color: var(--ps-light-blue);
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 2px solid #28a745;
            color: #28a745;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="carrinho.php">
                            <i class="fas fa-shopping-cart"></i> Carrinho 
                            <?php if(contarItensCarrinho() > 0): ?>
                                <span class="badge bg-danger"><?php echo contarItensCarrinho(); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if(isLogado()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="minha-conta.php"><i class="fas fa-user"></i> Minha Conta</a>
                        </li>
                        <?php if(isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/index.php"><i class="fas fa-cog"></i> Admin</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Breadcrumb -->
        <nav class="breadcrumb">
            <a href="index.php"><i class="fas fa-home"></i> Início</a>
            <span class="mx-2">/</span>
            <a href="index.php?categoria=<?php echo $produto['categoria_id']; ?>"><?php echo htmlspecialchars($produto['categoria_nome']); ?></a>
            <span class="mx-2">/</span>
            <span class="text-white"><?php echo htmlspecialchars($produto['nome']); ?></span>
        </nav>

        <!-- Mensagem de sucesso -->
        <?php if(isset($_SESSION['mensagem_sucesso'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['mensagem_sucesso']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['mensagem_sucesso']); ?>
        <?php endif; ?>

        <!-- Detalhes do Produto -->
        <div class="product-detail-container">
            <div class="row">
                <div class="col-md-6">
                    <div class="product-image-main">
                        <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" 
                             alt="<?php echo htmlspecialchars($produto['nome']); ?>"
                             onerror="this.src='https://via.placeholder.com/500x500/1a1a2e/0070CC?text=<?php echo urlencode($produto['nome']); ?>'">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <span class="product-category-badge">
                        <i class="fas fa-tag"></i> <?php echo htmlspecialchars($produto['categoria_nome']); ?>
                    </span>
                    
                    <h1 class="product-title"><?php echo htmlspecialchars($produto['nome']); ?></h1>
                    
                    <div class="product-price">
                        <?php echo formatarPreco($produto['preco']); ?>
                    </div>
                    
                    <!-- Status do Estoque -->
                    <?php if($produto['estoque'] > 10): ?>
                        <span class="stock-badge stock-available">
                            <i class="fas fa-check-circle"></i> Em estoque (<?php echo $produto['estoque']; ?> unidades)
                        </span>
                    <?php elseif($produto['estoque'] > 0): ?>
                        <span class="stock-badge stock-low">
                            <i class="fas fa-exclamation-triangle"></i> Últimas unidades! (<?php echo $produto['estoque']; ?> restantes)
                        </span>
                    <?php else: ?>
                        <span class="stock-badge stock-out">
                            <i class="fas fa-times-circle"></i> Fora de estoque
                        </span>
                    <?php endif; ?>
                    
                    <!-- Informações do Produto -->
                    <div class="mt-4">
                        <?php if($produto['desenvolvedor']): ?>
                            <div class="product-info-item">
                                <strong><i class="fas fa-building"></i> Desenvolvedor:</strong> 
                                <?php echo htmlspecialchars($produto['desenvolvedor']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($produto['lancamento']): ?>
                            <div class="product-info-item">
                                <strong><i class="fas fa-calendar"></i> Lançamento:</strong> 
                                <?php echo $produto['lancamento']; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($produto['classificacao']): ?>
                            <div class="product-info-item">
                                <strong><i class="fas fa-shield-alt"></i> Classificação:</strong> 
                                <?php echo htmlspecialchars($produto['classificacao']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Formulário de Compra -->
                    <?php if($produto['estoque'] > 0): ?>
                        <form method="POST" class="mt-4">
                            <div class="quantity-selector">
                                <label style="font-weight: 600;"><i class="fas fa-sort-numeric-up"></i> Quantidade:</label>
                                <button type="button" class="quantity-btn" onclick="decrementQuantity()">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" name="quantidade" id="quantidade" value="1" min="1" max="<?php echo $produto['estoque']; ?>">
                                <button type="button" class="quantity-btn" onclick="incrementQuantity(<?php echo $produto['estoque']; ?>)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" name="adicionar_carrinho" class="btn btn-ps5 btn-lg">
                                    <i class="fas fa-shopping-cart"></i> ADICIONAR AO CARRINHO
                                </button>
                                <a href="carrinho.php" class="btn btn-outline-light btn-lg">
                                    <i class="fas fa-eye"></i> Ver Carrinho
                                </a>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-danger mt-4">
                            <i class="fas fa-exclamation-circle"></i> Produto indisponível no momento.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Descrição -->
            <?php if($produto['descricao']): ?>
                <div class="product-description">
                    <h3><i class="fas fa-info-circle"></i> Sobre o Jogo</h3>
                    <p style="font-size: 1.1rem; line-height: 1.8;">
                        <?php echo nl2br(htmlspecialchars($produto['descricao'])); ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Produtos Relacionados -->
        <?php if($relacionados->num_rows > 0): ?>
            <div class="related-products">
                <h2 class="text-center mb-4">
                    <i class="fas fa-gamepad"></i> VOCÊ TAMBÉM PODE GOSTAR
                </h2>
                <div class="row g-4">
                    <?php while($relacionado = $relacionados->fetch_assoc()): ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="product-card">
                                <div class="product-card-image">
                                    <img src="uploads/<?php echo htmlspecialchars($relacionado['imagem']); ?>" 
                                         alt="<?php echo htmlspecialchars($relacionado['nome']); ?>"
                                         onerror="this.src='https://via.placeholder.com/300x300/1a1a2e/0070CC?text=<?php echo urlencode($relacionado['nome']); ?>'">
                                </div>
                                <div class="p-3">
                                    <div style="color: var(--ps-light-blue); font-size: 0.9rem; margin-bottom: 8px;">
                                        <?php echo htmlspecialchars($relacionado['categoria_nome']); ?>
                                    </div>
                                    <h5 style="color: white; min-height: 50px; font-size: 1rem;">
                                        <?php echo htmlspecialchars($relacionado['nome']); ?>
                                    </h5>
                                    <div style="font-size: 1.5rem; font-weight: 700; color: var(--ps-light-blue); margin: 10px 0;">
                                        <?php echo formatarPreco($relacionado['preco']); ?>
                                    </div>
                                    <a href="produto.php?id=<?php echo $relacionado['id']; ?>" class="btn btn-ps5 w-100">
                                        <i class="fas fa-eye"></i> Ver Detalhes
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function incrementQuantity(max) {
            let input = document.getElementById('quantidade');
            let value = parseInt(input.value);
            if (value < max) {
                input.value = value + 1;
            }
        }
        
        function decrementQuantity() {
            let input = document.getElementById('quantidade');
            let value = parseInt(input.value);
            if (value > 1) {
                input.value = value - 1;
            }
        }
    </script>
</body>
</html>