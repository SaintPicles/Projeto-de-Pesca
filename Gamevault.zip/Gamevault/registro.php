<?php
require_once 'config.php';

// Redirecionar se já estiver logado
if (isLogado()) {
    header('Location: index.php');
    exit();
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = limparInput($_POST['nome']);
    $email = limparInput($_POST['email']);
    $senha = $_POST['senha'];
    $confirmar_senha = $_POST['confirmar_senha'];
    
    // Validações
    if (empty($nome) || empty($email) || empty($senha) || empty($confirmar_senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter no mínimo 6 caracteres.';
    } elseif ($senha !== $confirmar_senha) {
        $erro = 'As senhas não coincidem.';
    } else {
        // Verificar se o email já existe
        $sql = "SELECT id FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $erro = 'Este e-mail já está cadastrado.';
        } else {
            // Criar hash da senha
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            
            // Inserir usuário
            $sql = "INSERT INTO users (nome, email, senha, tipo) VALUES ('$nome', '$email', '$senha_hash', 'cliente')";
            
            if ($conn->query($sql)) {
                $usuario_id = $conn->insert_id;
                
                // Fazer login automaticamente
                $_SESSION['usuario_id'] = $usuario_id;
                $_SESSION['usuario_nome'] = $nome;
                $_SESSION['usuario_email'] = $email;
                $_SESSION['usuario_tipo'] = 'cliente';
                
                // Redirecionar
                if (isset($_SESSION['redirect_after_login'])) {
                    $redirect = $_SESSION['redirect_after_login'];
                    unset($_SESSION['redirect_after_login']);
                    header('Location: ' . $redirect);
                } else {
                    header('Location: index.php');
                }
                exit();
            } else {
                $erro = 'Erro ao criar conta. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 0;
        }
        
        .register-container {
            background: rgba(31, 31, 31, 0.95);
            border: 2px solid var(--ps-blue);
            border-radius: 20px;
            padding: 50px;
            max-width: 550px;
            width: 100%;
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.5);
            backdrop-filter: blur(10px);
            margin: 20px;
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .register-header h1 {
            font-size: 2.5rem;
            font-weight: 800;
            text-transform: uppercase;
            color: white;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(0, 112, 204, 0.8);
        }
        
        .register-header .logo {
            font-size: 4rem;
            color: var(--ps-light-blue);
            margin-bottom: 20px;
        }
        
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 1rem;
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--ps-light-blue);
            color: white;
            box-shadow: 0 0 15px rgba(0, 112, 204, 0.5);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .form-label {
            font-weight: 600;
            color: var(--ps-light-blue);
            margin-bottom: 8px;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 700;
            padding: 15px;
            border-radius: 10px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 2px solid #dc3545;
            color: #ff6b6b;
            border-radius: 10px;
        }
        
        .divider {
            text-align: center;
            margin: 30px 0;
            position: relative;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: rgba(255, 255, 255, 0.2);
        }
        
        .divider span {
            background: rgba(31, 31, 31, 0.95);
            padding: 0 15px;
            position: relative;
            color: rgba(255, 255, 255, 0.6);
        }
        
        .back-home {
            position: fixed;
            top: 30px;
            left: 30px;
        }
        
        .back-home a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .back-home a:hover {
            color: var(--ps-light-blue);
        }
        
        .password-strength {
            height: 5px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="back-home">
        <a href="index.php">
            <i class="fas fa-arrow-left"></i> Voltar à Loja
        </a>
    </div>

    <div class="register-container">
        <div class="register-header">
            <div class="logo">
                <i class="fas fa-user-plus"></i>
            </div>
            <h1>CADASTRO</h1>
            <p style="color: rgba(255, 255, 255, 0.7);">Crie sua conta GameVault</p>
        </div>

        <?php if (!empty($erro)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $erro; ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="formRegistro">
            <div class="mb-3">
                <label for="nome" class="form-label">
                    <i class="fas fa-user"></i> Nome Completo
                </label>
                <input type="text" class="form-control" id="nome" name="nome" 
                       placeholder="Digite seu nome completo" required
                       value="<?php echo isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : ''; ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">
                    <i class="fas fa-envelope"></i> E-mail
                </label>
                <input type="email" class="form-control" id="email" name="email" 
                       placeholder="seu@email.com" required
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>

            <div class="mb-3">
                <label for="senha" class="form-label">
                    <i class="fas fa-lock"></i> Senha
                </label>
                <input type="password" class="form-control" id="senha" name="senha" 
                       placeholder="Mínimo 6 caracteres" required minlength="6"
                       onkeyup="verificarForcaSenha()">
                <div class="password-strength">
                    <div class="password-strength-bar" id="strengthBar"></div>
                </div>
                <small id="strengthText" style="color: rgba(255, 255, 255, 0.6);"></small>
            </div>

            <div class="mb-4">
                <label for="confirmar_senha" class="form-label">
                    <i class="fas fa-lock"></i> Confirmar Senha
                </label>
                <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" 
                       placeholder="Digite a senha novamente" required minlength="6">
            </div>

            <button type="submit" class="btn btn-ps5 w-100">
                <i class="fas fa-user-plus"></i> CRIAR CONTA
            </button>
        </form>

        <div class="divider">
            <span>OU</span>
        </div>

        <div class="text-center">
            <p style="color: rgba(255, 255, 255, 0.7);">
                Já tem uma conta?
            </p>
            <a href="login.php" class="btn btn-outline-light w-100">
                <i class="fas fa-sign-in-alt"></i> FAZER LOGIN
            </a>
        </div>

        <div class="text-center mt-4">
            <small style="color: rgba(255, 255, 255, 0.5);">
                <i class="fas fa-lock"></i> Seus dados estão protegidos
            </small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function verificarForcaSenha() {
            const senha = document.getElementById('senha').value;
            const strengthBar = document.getElementById('strengthBar');
            const strengthText = document.getElementById('strengthText');
            
            let forca = 0;
            
            if (senha.length >= 6) forca += 25;
            if (senha.length >= 10) forca += 25;
            if (/[a-z]/.test(senha) && /[A-Z]/.test(senha)) forca += 25;
            if (/\d/.test(senha)) forca += 25;
            
            strengthBar.style.width = forca + '%';
            
            if (forca <= 25) {
                strengthBar.style.background = '#dc3545';
                strengthText.textContent = 'Senha fraca';
                strengthText.style.color = '#dc3545';
            } else if (forca <= 50) {
                strengthBar.style.background = '#ffc107';
                strengthText.textContent = 'Senha média';
                strengthText.style.color = '#ffc107';
            } else if (forca <= 75) {
                strengthBar.style.background = '#28a745';
                strengthText.textContent = 'Senha boa';
                strengthText.style.color = '#28a745';
            } else {
                strengthBar.style.background = '#00ff00';
                strengthText.textContent = 'Senha forte';
                strengthText.style.color = '#00ff00';
            }
        }
        
        document.getElementById('formRegistro').addEventListener('submit', function(e) {
            const senha = document.getElementById('senha').value;
            const confirmar = document.getElementById('confirmar_senha').value;
            
            if (senha !== confirmar) {
                e.preventDefault();
                alert('As senhas não coincidem!');
                return false;
            }
        });
    </script>
</body>
</html>