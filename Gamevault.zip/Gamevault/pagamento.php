<?php
require_once 'config.php';

redirecionarSeNaoLogado();

// Verificar se tem carrinho e método de pagamento
if (empty($_SESSION['carrinho']) || !isset($_POST['metodo_pagamento'])) {
    header('Location: carrinho.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$metodo_pagamento = limparInput($_POST['metodo_pagamento']);

// Buscar dados do usuário
$sql_usuario = "SELECT * FROM users WHERE id = $usuario_id";
$usuario = $conn->query($sql_usuario)->fetch_assoc();

// Verificar se tem endereço completo
if (empty($usuario['endereco']) || empty($usuario['cidade']) || empty($usuario['estado'])) {
    header('Location: checkout.php');
    exit();
}

// Calcular totais
$subtotal = calcularTotalCarrinho();
$frete = 15.00;
$desconto = 0;

if (isset($_SESSION['cupom_aplicado'])) {
    $desconto_cupom = $_SESSION['cupom_aplicado']['desconto'];
    if ($_SESSION['cupom_aplicado']['tipo'] === 'percentual') {
        $desconto = $subtotal * ($desconto_cupom / 100);
    } else {
        $desconto = $desconto_cupom;
    }
}

$total = $subtotal + $frete - $desconto;

// Endereço completo
$endereco_entrega = $usuario['endereco'] . ', ' . $usuario['cidade'] . ' - ' . 
                    $usuario['estado'] . ', CEP: ' . $usuario['cep'];

// Criar pedido
$conn->begin_transaction();

try {
    // Inserir pedido
    $sql = "INSERT INTO orders (cliente_id, total, status, metodo_pagamento, endereco_entrega) 
            VALUES ($usuario_id, $total, 'Pendente', '$metodo_pagamento', '$endereco_entrega')";
    
    if (!$conn->query($sql)) {
        throw new Exception('Erro ao criar pedido');
    }
    
    $pedido_id = $conn->insert_id;
    
    // Inserir itens do pedido
    foreach ($_SESSION['carrinho'] as $produto_id => $quantidade) {
        // Buscar produto
        $sql = "SELECT * FROM products WHERE id = $produto_id";
        $produto = $conn->query($sql)->fetch_assoc();
        
        if (!$produto || $produto['estoque'] < $quantidade) {
            throw new Exception('Produto indisponível ou estoque insuficiente');
        }
        
        $valor_unitario = $produto['preco'];
        
        // Inserir item do pedido
        $sql = "INSERT INTO order_items (pedido_id, produto_id, quantidade, valor_unitario) 
                VALUES ($pedido_id, $produto_id, $quantidade, $valor_unitario)";
        
        if (!$conn->query($sql)) {
            throw new Exception('Erro ao adicionar item do pedido');
        }
    }
    
    $conn->commit();
    
    // Limpar carrinho e cupom
    $_SESSION['carrinho'] = array();
    if (isset($_SESSION['cupom_aplicado'])) {
        unset($_SESSION['cupom_aplicado']);
    }
    
    // Redirecionar para página de confirmação
    $_SESSION['pedido_realizado'] = $pedido_id;
    header('Location: confirmacao-pedido.php?id=' . $pedido_id);
    exit();
    
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['mensagem_erro'] = 'Erro ao processar pedido: ' . $e->getMessage();
    header('Location: checkout.php');
    exit();
}
?>