<?php
// config.php - Configuração do banco de dados e sessão
session_start();

// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gamevault_store');

// Conectar ao banco de dados
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Funções auxiliares
function limparInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

function formatarPreco($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

function isLogado() {
    return isset($_SESSION['usuario_id']);
}

function isAdmin() {
    return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'admin';
}

function redirecionarSeNaoLogado() {
    if (!isLogado()) {
        header('Location: login.php');
        exit();
    }
}

function redirecionarSeNaoAdmin() {
    if (!isAdmin()) {
        header('Location: index.php');
        exit();
    }
}

// Inicializar carrinho se não existir
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = array();
}

// Função para adicionar ao carrinho
function adicionarAoCarrinho($produto_id, $quantidade = 1) {
    if (isset($_SESSION['carrinho'][$produto_id])) {
        $_SESSION['carrinho'][$produto_id] += $quantidade;
    } else {
        $_SESSION['carrinho'][$produto_id] = $quantidade;
    }
}

// Função para remover do carrinho
function removerDoCarrinho($produto_id) {
    if (isset($_SESSION['carrinho'][$produto_id])) {
        unset($_SESSION['carrinho'][$produto_id]);
    }
}

// Função para atualizar quantidade no carrinho
function atualizarQuantidadeCarrinho($produto_id, $quantidade) {
    if ($quantidade <= 0) {
        removerDoCarrinho($produto_id);
    } else {
        $_SESSION['carrinho'][$produto_id] = $quantidade;
    }
}

// Função para calcular total do carrinho
function calcularTotalCarrinho() {
    global $conn;
    $total = 0;
    
    if (empty($_SESSION['carrinho'])) {
        return 0;
    }
    
    $ids = array_keys($_SESSION['carrinho']);
    $ids_str = implode(',', $ids);
    
    $sql = "SELECT id, preco FROM products WHERE id IN ($ids_str)";
    $result = $conn->query($sql);
    
    while ($produto = $result->fetch_assoc()) {
        $quantidade = $_SESSION['carrinho'][$produto['id']];
        $total += $produto['preco'] * $quantidade;
    }
    
    return $total;
}

// Função para contar itens no carrinho
function contarItensCarrinho() {
    return array_sum($_SESSION['carrinho']);
}

// Função para gerar código de pedido
function gerarCodigoPedido() {
    return 'GV' . date('Ymd') . rand(1000, 9999);
}
?>