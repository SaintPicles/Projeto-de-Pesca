<?php
require_once 'config.php';

redirecionarSeNaoLogado();

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$pedido_id = intval($_GET['id']);
$usuario_id = $_SESSION['usuario_id'];

// Buscar pedido
$sql = "SELECT o.*, u.nome as cliente_nome, u.email as cliente_email 
        FROM orders o 
        INNER JOIN users u ON o.cliente_id = u.id 
        WHERE o.id = $pedido_id AND o.cliente_id = $usuario_id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    header('Location: index.php');
    exit();
}

$pedido = $result->fetch_assoc();

// Buscar itens do pedido
$sql_itens = "SELECT oi.*, p.nome as produto_nome, p.imagem as produto_imagem 
              FROM order_items oi 
              INNER JOIN products p ON oi.produto_id = p.id 
              WHERE oi.pedido_id = $pedido_id";
$itens = $conn->query($sql_itens);

// Gerar código de pagamento simulado
$codigo_pagamento = '';
switch($pedido['metodo_pagamento']) {
    case 'pix':
        $codigo_pagamento = strtoupper(substr(md5($pedido_id . time()), 0, 32));
        break;
    case 'boleto':
        $codigo_pagamento = '23790.12345 67890.123456 78901.234567 8 12340000' . number_format($pedido['total'], 2, '', '');
        break;
    case 'cartao':
        $codigo_pagamento = 'Autorização: ' . rand(100000, 999999);
        break;
}

// Processar confirmação de pagamento (simulado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_pagamento'])) {
    // Atualizar status do pedido
    $sql = "UPDATE orders SET status = 'Pago', data_pagamento = NOW() WHERE id = $pedido_id";
    $conn->query($sql);
    
    // Atualizar estoque
    $itens->data_seek(0);
    while ($item = $itens->fetch_assoc()) {
        $sql = "UPDATE products SET estoque = estoque - {$item['quantidade']} WHERE id = {$item['produto_id']}";
        $conn->query($sql);
    }
    
    $_SESSION['mensagem_sucesso'] = 'Pagamento confirmado! Pedido em processamento.';
    header('Location: minha-conta.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedido Confirmado - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: white !important;
        }
        
        .success-container {
            background: rgba(31, 31, 31, 0.9);
            border-radius: 20px;
            padding: 50px;
            margin: 50px auto;
            max-width: 900px;
            border: 2px solid #28a745;
            box-shadow: 0 10px 50px rgba(40, 167, 69, 0.3);
        }
        
        .success-icon {
            font-size: 5rem;
            color: #28a745;
            text-align: center;
            margin-bottom: 30px;
            animation: checkmark 0.5s ease-in-out;
        }
        
        @keyframes checkmark {
            0% { transform: scale(0); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        .order-number {
            background: rgba(0, 112, 204, 0.3);
            border: 2px solid var(--ps-light-blue);
            border-radius: 15px;
            padding: 25px;
            margin: 30px 0;
            text-align: center;
        }
        
        .order-number h2 {
            font-size: 2.5rem;
            color: var(--ps-light-blue);
            margin: 0;
        }
        
        .payment-box {
            background: rgba(0, 67, 156, 0.2);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 30px;
            margin: 30px 0;
        }
        
        .qr-code-placeholder {
            width: 200px;
            height: 200px;
            background: white;
            margin: 20px auto;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .code-box {
            background: rgba(255, 255, 255, 0.1);
            border: 2px dashed var(--ps-light-blue);
            border-radius: 10px;
            padding: 15px;
            font-family: monospace;
            font-size: 0.9rem;
            word-break: break-all;
            text-align: center;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 25px;
            transition: all 0.3s;
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="success-container">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            
            <h1 class="text-center mb-3" style="font-size: 2.5rem; font-weight: 800;">
                PEDIDO REALIZADO COM SUCESSO!
            </h1>
            
            <p class="text-center lead">Obrigado por comprar na GameVault, <?php echo htmlspecialchars($pedido['cliente_nome']); ?>!</p>
            
            <div class="order-number">
                <p style="margin: 0; font-size: 1rem; color: rgba(255,255,255,0.7);">Número do Pedido:</p>
                <h2>#<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?></h2>
                <p style="margin: 10px 0 0 0; color: rgba(255,255,255,0.7);">
                    Data: <?php echo date('d/m/Y H:i', strtotime($pedido['data_criacao'])); ?>
                </p>
            </div>

            <!-- Detalhes do Pagamento -->
            <div class="payment-box">
                <h3 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                    <i class="fas fa-credit-card"></i> 
                    <?php 
                    switch($pedido['metodo_pagamento']) {
                        case 'pix': echo 'Pagamento via PIX'; break;
                        case 'boleto': echo 'Boleto Bancário'; break;
                        case 'cartao': echo 'Cartão de Crédito'; break;
                    }
                    ?>
                </h3>
                
                <?php if($pedido['metodo_pagamento'] === 'pix'): ?>
                    <p class="text-center">Escaneie o QR Code ou copie o código abaixo para realizar o pagamento:</p>
                    <div class="qr-code-placeholder">
                        <i class="fas fa-qrcode" style="font-size: 8rem; color: black;"></i>
                    </div>
                    <div class="code-box">
                        <?php echo $codigo_pagamento; ?>
                    </div>
                    <div class="text-center mt-3">
                        <button class="btn btn-outline-light" onclick="copiarCodigo()">
                            <i class="fas fa-copy"></i> Copiar Código PIX
                        </button>
                    </div>
                    
                <?php elseif($pedido['metodo_pagamento'] === 'boleto'): ?>
                    <p class="text-center">Código de barras do boleto:</p>
                    <div class="code-box">
                        <?php echo $codigo_pagamento; ?>
                    </div>
                    <div class="text-center mt-3">
                        <button class="btn btn-outline-light" onclick="copiarCodigo()">
                            <i class="fas fa-copy"></i> Copiar Código de Barras
                        </button>
                        <a href="#" class="btn btn-outline-light">
                            <i class="fas fa-download"></i> Baixar Boleto PDF
                        </a>
                    </div>
                    <p class="text-center mt-3" style="color: rgba(255,255,255,0.7);">
                        Vencimento: <?php echo date('d/m/Y', strtotime('+3 days')); ?>
                    </p>
                    
                <?php else: ?>
                    <div class="text-center">
                        <i class="fas fa-check-circle" style="font-size: 4rem; color: #28a745; margin: 20px 0;"></i>
                        <p><?php echo $codigo_pagamento; ?></p>
                        <p style="color: #28a745; font-weight: 600;">Pagamento Aprovado!</p>
                    </div>
                <?php endif; ?>
                
                <div class="alert alert-info mt-4" style="background: rgba(0, 112, 204, 0.2); border: 2px solid var(--ps-light-blue); color: white;">
                    <i class="fas fa-info-circle"></i>
                    <?php if($pedido['metodo_pagamento'] === 'cartao'): ?>
                        Seu pedido já está sendo processado e será enviado em breve!
                    <?php else: ?>
                        Após a confirmação do pagamento, seu pedido será processado automaticamente.
                    <?php endif; ?>
                </div>
            </div>

            <!-- Simulação de Confirmação de Pagamento -->
            <?php if($pedido['metodo_pagamento'] !== 'cartao'): ?>
                <div class="text-center mt-4">
                    <form method="POST">
                        <button type="submit" name="confirmar_pagamento" class="btn btn-success btn-lg">
                            <i class="fas fa-check"></i> SIMULAR CONFIRMAÇÃO DE PAGAMENTO
                        </button>
                        <p class="mt-2" style="font-size: 0.9rem; color: rgba(255,255,255,0.6);">
                            (Apenas para demonstração - Em produção, seria automático)
                        </p>
                    </form>
                </div>
            <?php endif; ?>

            <!-- Itens do Pedido -->
            <div class="mt-5">
                <h3 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                    <i class="fas fa-box"></i> Itens do Pedido
                </h3>
                <?php while($item = $itens->fetch_assoc()): ?>
                    <div style="background: rgba(0, 67, 156, 0.1); border-radius: 10px; padding: 15px; margin-bottom: 10px; display: flex; align-items: center; gap: 20px;">
                        <img src="uploads/<?php echo htmlspecialchars($item['produto_imagem']); ?>" 
                             style="width: 60px; height: 60px; border-radius: 5px; object-fit: cover;"
                             onerror="this.src='https://via.placeholder.com/60x60/1a1a2e/0070CC'">
                        <div style="flex: 1;">
                            <strong><?php echo htmlspecialchars($item['produto_nome']); ?></strong>
                            <p style="margin: 5px 0 0 0; color: rgba(255,255,255,0.7);">
                                Quantidade: <?php echo $item['quantidade']; ?> x <?php echo formatarPreco($item['valor_unitario']); ?>
                            </p>
                        </div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: var(--ps-light-blue);">
                            <?php echo formatarPreco($item['quantidade'] * $item['valor_unitario']); ?>
                        </div>
                    </div>
                <?php endwhile; ?>
                
                <div style="text-align: right; margin-top: 20px; padding-top: 20px; border-top: 2px solid rgba(255,255,255,0.2);">
                    <h3 style="color: var(--ps-light-blue);">
                        Total: <?php echo formatarPreco($pedido['total']); ?>
                    </h3>
                </div>
            </div>

            <div class="text-center mt-5">
                <a href="index.php" class="btn btn-ps5 btn-lg">
                    <i class="fas fa-home"></i> VOLTAR À LOJA
                </a>
                <a href="minha-conta.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-user"></i> MEUS PEDIDOS
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copiarCodigo() {
            const codigo = document.querySelector('.code-box').textContent;
            navigator.clipboard.writeText(codigo).then(() => {
                alert('Código copiado!');
            });
        }
    </script>
</body>
</html>