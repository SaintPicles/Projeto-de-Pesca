<?php
require_once 'config.php';

redirecionarSeNaoLogado();

$usuario_id = $_SESSION['usuario_id'];

// Buscar dados do usuário
$sql_usuario = "SELECT * FROM users WHERE id = $usuario_id";
$usuario = $conn->query($sql_usuario)->fetch_assoc();

// Buscar pedidos do usuário
$sql_pedidos = "SELECT * FROM orders WHERE cliente_id = $usuario_id ORDER BY data_criacao DESC";
$pedidos = $conn->query($sql_pedidos);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: white !important;
        }
        
        .nav-link {
            color: white !important;
        }
        
        .nav-link:hover {
            color: var(--ps-light-blue) !important;
        }
        
        .account-container {
            background: rgba(31, 31, 31, 0.9);
            border-radius: 20px;
            padding: 40px;
            margin: 30px 0;
            border: 2px solid var(--ps-blue);
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.3);
        }
        
        .profile-header {
            background: rgba(0, 112, 204, 0.2);
            border: 2px solid var(--ps-light-blue);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
        }
        
        .order-card {
            background: rgba(0, 67, 156, 0.2);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .order-card:hover {
            border-color: var(--ps-light-blue);
            box-shadow: 0 5px 20px rgba(0, 112, 204, 0.3);
        }
        
        .status-badge {
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
        }
        
        .status-pendente {
            background: rgba(255, 193, 7, 0.3);
            color: #ffc107;
            border: 2px solid #ffc107;
        }
        
        .status-processando {
            background: rgba(0, 123, 255, 0.3);
            color: #007bff;
            border: 2px solid #007bff;
        }
        
        .status-pago {
            background: rgba(40, 167, 69, 0.3);
            color: #28a745;
            border: 2px solid #28a745;
        }
        
        .status-enviado {
            background: rgba(23, 162, 184, 0.3);
            color: #17a2b8;
            border: 2px solid #17a2b8;
        }
        
        .status-entregue {
            background: rgba(40, 167, 69, 0.3);
            color: #28a745;
            border: 2px solid #28a745;
        }
        
        .status-cancelado {
            background: rgba(220, 53, 69, 0.3);
            color: #dc3545;
            border: 2px solid #dc3545;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 25px;
            transition: all 0.3s;
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            color: white;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 2px solid #28a745;
            color: #28a745;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="carrinho.php">
                            <i class="fas fa-shopping-cart"></i> Carrinho
                            <?php if(contarItensCarrinho() > 0): ?>
                                <span class="badge bg-danger"><?php echo contarItensCarrinho(); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="minha-conta.php"><i class="fas fa-user"></i> Minha Conta</a>
                    </li>
                    <?php if(isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin/index.php"><i class="fas fa-cog"></i> Admin</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if(isset($_SESSION['mensagem_sucesso'])): ?>
            <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['mensagem_sucesso']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['mensagem_sucesso']); ?>
        <?php endif; ?>

        <div class="account-container">
            <!-- Cabeçalho do Perfil -->
            <div class="profile-header">
                <div class="profile-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div style="flex: 1;">
                    <h2 style="margin: 0; font-weight: 800; font-size: 2rem;">
                        <?php echo htmlspecialchars($usuario['nome']); ?>
                    </h2>
                    <p style="margin: 5px 0 0 0; color: var(--ps-light-blue);">
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($usuario['email']); ?>
                    </p>
                    <?php if($usuario['telefone']): ?>
                        <p style="margin: 5px 0 0 0; color: rgba(255,255,255,0.8);">
                            <i class="fas fa-phone"></i> <?php echo htmlspecialchars($usuario['telefone']); ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div>
                    <?php if(isAdmin()): ?>
                        <span class="status-badge" style="background: rgba(255, 193, 7, 0.3); color: #ffc107; border: 2px solid #ffc107;">
                            <i class="fas fa-crown"></i> ADMIN
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Estatísticas -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div style="background: rgba(0, 112, 204, 0.2); border: 2px solid var(--ps-light-blue); border-radius: 15px; padding: 25px; text-align: center;">
                        <i class="fas fa-shopping-bag fa-3x" style="color: var(--ps-light-blue); margin-bottom: 15px;"></i>
                        <h3 style="margin: 0; font-size: 2.5rem; color: var(--ps-light-blue);">
                            <?php echo $pedidos->num_rows; ?>
                        </h3>
                        <p style="margin: 5px 0 0 0; color: rgba(255,255,255,0.8);">Total de Pedidos</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div style="background: rgba(40, 167, 69, 0.2); border: 2px solid #28a745; border-radius: 15px; padding: 25px; text-align: center;">
                        <i class="fas fa-check-circle fa-3x" style="color: #28a745; margin-bottom: 15px;"></i>
                        <h3 style="margin: 0; font-size: 2.5rem; color: #28a745;">
                            <?php 
                            $sql_completos = "SELECT COUNT(*) as total FROM orders WHERE cliente_id = $usuario_id AND status IN ('Pago', 'Enviado', 'Entregue')";
                            $completos = $conn->query($sql_completos)->fetch_assoc()['total'];
                            echo $completos;
                            ?>
                        </h3>
                        <p style="margin: 5px 0 0 0; color: rgba(255,255,255,0.8);">Pedidos Completos</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div style="background: rgba(255, 193, 7, 0.2); border: 2px solid #ffc107; border-radius: 15px; padding: 25px; text-align: center;">
                        <i class="fas fa-clock fa-3x" style="color: #ffc107; margin-bottom: 15px;"></i>
                        <h3 style="margin: 0; font-size: 2.5rem; color: #ffc107;">
                            <?php 
                            $sql_pendentes = "SELECT COUNT(*) as total FROM orders WHERE cliente_id = $usuario_id AND status = 'Pendente'";
                            $pendentes = $conn->query($sql_pendentes)->fetch_assoc()['total'];
                            echo $pendentes;
                            ?>
                        </h3>
                        <p style="margin: 5px 0 0 0; color: rgba(255,255,255,0.8);">Pedidos Pendentes</p>
                    </div>
                </div>
            </div>

            <!-- Histórico de Pedidos -->
            <h3 style="color: var(--ps-light-blue); margin: 40px 0 20px 0;">
                <i class="fas fa-history"></i> HISTÓRICO DE PEDIDOS
            </h3>

            <?php if($pedidos->num_rows > 0): ?>
                <?php while($pedido = $pedidos->fetch_assoc()): ?>
                    <div class="order-card">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <div style="font-weight: 700; font-size: 1.2rem;">
                                    #<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?>
                                </div>
                                <div style="font-size: 0.9rem; color: rgba(255,255,255,0.7);">
                                    <?php echo date('d/m/Y', strtotime($pedido['data_criacao'])); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Método:</div>
                                <div style="font-weight: 600;">
                                    <?php 
                                    switch($pedido['metodo_pagamento']) {
                                        case 'pix': echo '<i class="fas fa-qrcode"></i> PIX'; break;
                                        case 'boleto': echo '<i class="fas fa-barcode"></i> Boleto'; break;
                                        case 'cartao': echo '<i class="fas fa-credit-card"></i> Cartão'; break;
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">Total:</div>
                                <div style="font-weight: 700; font-size: 1.3rem; color: var(--ps-light-blue);">
                                    <?php echo formatarPreco($pedido['total']); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <span class="status-badge status-<?php echo strtolower($pedido['status']); ?>">
                                    <?php echo strtoupper($pedido['status']); ?>
                                </span>
                            </div>
                            <div class="col-md-2 text-end">
                                <a href="confirmacao-pedido.php?id=<?php echo $pedido['id']; ?>" class="btn btn-ps5 btn-sm">
                                    <i class="fas fa-eye"></i> Detalhes
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="background: rgba(0, 67, 156, 0.1); border: 2px solid var(--ps-blue); border-radius: 15px; padding: 50px; text-align: center;">
                    <i class="fas fa-shopping-bag" style="font-size: 5rem; color: rgba(255,255,255,0.3); margin-bottom: 20px;"></i>
                    <h4>Você ainda não fez nenhum pedido</h4>
                    <p style="color: rgba(255,255,255,0.7);">Explore nosso catálogo e encontre jogos incríveis!</p>
                    <a href="index.php" class="btn btn-ps5 btn-lg mt-3">
                        <i class="fas fa-gamepad"></i> EXPLORAR CATÁLOGO
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>