<?php
require_once 'config.php';

// Verificar se o carrinho está vazio
if (empty($_SESSION['carrinho'])) {
    header('Location: carrinho.php');
    exit();
}

// Verificar se está logado
if (!isLogado()) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header('Location: login.php');
    exit();
}

// Buscar dados do usuário
$usuario_id = $_SESSION['usuario_id'];
$sql_usuario = "SELECT * FROM users WHERE id = $usuario_id";
$usuario = $conn->query($sql_usuario)->fetch_assoc();

// Calcular totais
$subtotal = calcularTotalCarrinho();
$frete = 15.00;
$desconto = 0;

if (isset($_SESSION['cupom_aplicado'])) {
    $desconto_cupom = $_SESSION['cupom_aplicado']['desconto'];
    if ($_SESSION['cupom_aplicado']['tipo'] === 'percentual') {
        $desconto = $subtotal * ($desconto_cupom / 100);
    } else {
        $desconto = $desconto_cupom;
    }
}

$total = $subtotal + $frete - $desconto;

// Processar endereço
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_endereco'])) {
    $endereco = limparInput($_POST['endereco']);
    $cidade = limparInput($_POST['cidade']);
    $estado = limparInput($_POST['estado']);
    $cep = limparInput($_POST['cep']);
    $telefone = limparInput($_POST['telefone']);
    
    $sql = "UPDATE users SET endereco = '$endereco', cidade = '$cidade', estado = '$estado', 
            cep = '$cep', telefone = '$telefone' WHERE id = $usuario_id";
    $conn->query($sql);
    
    // Atualizar dados do usuário
    $usuario = $conn->query($sql_usuario)->fetch_assoc();
    $_SESSION['mensagem_sucesso'] = 'Endereço atualizado!';
}

// Validar se tem endereço completo
$endereco_completo = !empty($usuario['endereco']) && !empty($usuario['cidade']) && 
                     !empty($usuario['estado']) && !empty($usuario['cep']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: white !important;
            text-transform: uppercase;
        }
        
        .checkout-container {
            background: rgba(31, 31, 31, 0.9);
            border-radius: 20px;
            padding: 40px;
            margin: 30px 0;
            border: 2px solid var(--ps-blue);
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.3);
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            position: relative;
        }
        
        .step-indicator::before {
            content: '';
            position: absolute;
            top: 25px;
            left: 50px;
            right: 50px;
            height: 2px;
            background: rgba(255, 255, 255, 0.2);
            z-index: 0;
        }
        
        .step {
            text-align: center;
            flex: 1;
            position: relative;
            z-index: 1;
        }
        
        .step-circle {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(0, 67, 156, 0.5);
            border: 2px solid var(--ps-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: 700;
        }
        
        .step.active .step-circle {
            background: var(--ps-light-blue);
            border-color: var(--ps-light-blue);
            box-shadow: 0 0 20px rgba(0, 112, 204, 0.8);
        }
        
        .step.completed .step-circle {
            background: #28a745;
            border-color: #28a745;
        }
        
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--ps-light-blue);
            color: white;
            box-shadow: 0 0 15px rgba(0, 112, 204, 0.5);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .form-label {
            font-weight: 600;
            color: var(--ps-light-blue);
            margin-bottom: 8px;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 25px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
        
        .payment-method {
            background: rgba(0, 67, 156, 0.2);
            border: 2px solid var(--ps-blue);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .payment-method:hover {
            border-color: var(--ps-light-blue);
            box-shadow: 0 5px 20px rgba(0, 112, 204, 0.3);
        }
        
        .payment-method.selected {
            border-color: var(--ps-light-blue);
            background: rgba(0, 112, 204, 0.3);
        }
        
        .summary-box {
            background: rgba(0, 67, 156, 0.2);
            border: 2px solid var(--ps-light-blue);
            border-radius: 15px;
            padding: 25px;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .summary-total {
            font-size: 2rem;
            font-weight: 800;
            color: var(--ps-light-blue);
            padding-top: 15px;
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="checkout-container">
            <h1 class="text-center mb-4" style="font-size: 2.5rem; font-weight: 800;">
                <i class="fas fa-credit-card"></i> FINALIZAR COMPRA
            </h1>

            <!-- Indicador de Etapas -->
            <div class="step-indicator">
                <div class="step <?php echo $endereco_completo ? 'completed' : 'active'; ?>">
                    <div class="step-circle">1</div>
                    <div>Endereço</div>
                </div>
                <div class="step <?php echo $endereco_completo ? 'active' : ''; ?>">
                    <div class="step-circle">2</div>
                    <div>Pagamento</div>
                </div>
                <div class="step">
                    <div class="step-circle">3</div>
                    <div>Confirmação</div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-8">
                    <!-- Etapa 1: Endereço -->
                    <div class="mb-4">
                        <h3><i class="fas fa-map-marker-alt"></i> Endereço de Entrega</h3>
                        
                        <?php if ($endereco_completo): ?>
                            <div style="background: rgba(40, 167, 69, 0.2); border: 2px solid #28a745; border-radius: 15px; padding: 20px; margin: 20px 0;">
                                <h5 style="color: #28a745;"><i class="fas fa-check-circle"></i> Endereço Cadastrado</h5>
                                <p style="margin: 10px 0 5px 0;"><strong>Endereço:</strong> <?php echo htmlspecialchars($usuario['endereco']); ?></p>
                                <p style="margin: 5px 0;"><strong>Cidade/Estado:</strong> <?php echo htmlspecialchars($usuario['cidade']); ?> - <?php echo htmlspecialchars($usuario['estado']); ?></p>
                                <p style="margin: 5px 0;"><strong>CEP:</strong> <?php echo htmlspecialchars($usuario['cep']); ?></p>
                                <p style="margin: 5px 0;"><strong>Telefone:</strong> <?php echo htmlspecialchars($usuario['telefone']); ?></p>
                                <button class="btn btn-outline-light btn-sm mt-2" onclick="document.getElementById('formEndereco').style.display='block'">
                                    <i class="fas fa-edit"></i> Alterar Endereço
                                </button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" id="formEndereco" style="<?php echo $endereco_completo ? 'display:none;' : ''; ?>">
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label for="endereco" class="form-label">Endereço Completo</label>
                                    <input type="text" class="form-control" id="endereco" name="endereco" 
                                           value="<?php echo htmlspecialchars($usuario['endereco'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="cep" class="form-label">CEP</label>
                                    <input type="text" class="form-control" id="cep" name="cep" 
                                           value="<?php echo htmlspecialchars($usuario['cep'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="cidade" class="form-label">Cidade</label>
                                    <input type="text" class="form-control" id="cidade" name="cidade" 
                                           value="<?php echo htmlspecialchars($usuario['cidade'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="estado" class="form-label">Estado</label>
                                    <select class="form-control" id="estado" name="estado" required>
                                        <option value="">Selecione</option>
                                        <option value="SP" <?php echo ($usuario['estado'] ?? '') == 'SP' ? 'selected' : ''; ?>>SP</option>
                                        <option value="RJ" <?php echo ($usuario['estado'] ?? '') == 'RJ' ? 'selected' : ''; ?>>RJ</option>
                                        <option value="MG" <?php echo ($usuario['estado'] ?? '') == 'MG' ? 'selected' : ''; ?>>MG</option>
                                        <option value="RS" <?php echo ($usuario['estado'] ?? '') == 'RS' ? 'selected' : ''; ?>>RS</option>
                                        <option value="PR" <?php echo ($usuario['estado'] ?? '') == 'PR' ? 'selected' : ''; ?>>PR</option>
                                        <option value="SC" <?php echo ($usuario['estado'] ?? '') == 'SC' ? 'selected' : ''; ?>>SC</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="telefone" class="form-label">Telefone</label>
                                    <input type="text" class="form-control" id="telefone" name="telefone" 
                                           value="<?php echo htmlspecialchars($usuario['telefone'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <button type="submit" name="salvar_endereco" class="btn btn-ps5">
                                <i class="fas fa-save"></i> Salvar Endereço
                            </button>
                        </form>
                    </div>

                    <!-- Etapa 2: Pagamento -->
                    <?php if ($endereco_completo): ?>
                        <div class="mb-4">
                            <h3><i class="fas fa-credit-card"></i> Método de Pagamento</h3>
                            
                            <form action="pagamento.php" method="POST" id="formPagamento">
                                <div class="payment-method" onclick="selecionarPagamento('cartao')">
                                    <input type="radio" name="metodo_pagamento" value="cartao" id="cartao" required>
                                    <label for="cartao" style="margin-left: 10px; cursor: pointer;">
                                        <i class="fas fa-credit-card fa-2x" style="vertical-align: middle; color: var(--ps-light-blue);"></i>
                                        <strong style="font-size: 1.2rem; margin-left: 15px;">Cartão de Crédito</strong>
                                        <p style="margin: 10px 0 0 55px; color: rgba(255,255,255,0.7);">Parcelamento em até 12x</p>
                                    </label>
                                </div>

                                <div class="payment-method" onclick="selecionarPagamento('pix')">
                                    <input type="radio" name="metodo_pagamento" value="pix" id="pix" required>
                                    <label for="pix" style="margin-left: 10px; cursor: pointer;">
                                        <i class="fas fa-qrcode fa-2x" style="vertical-align: middle; color: var(--ps-light-blue);"></i>
                                        <strong style="font-size: 1.2rem; margin-left: 15px;">PIX</strong>
                                        <p style="margin: 10px 0 0 55px; color: rgba(255,255,255,0.7);">Aprovação imediata</p>
                                    </label>
                                </div>

                                <div class="payment-method" onclick="selecionarPagamento('boleto')">
                                    <input type="radio" name="metodo_pagamento" value="boleto" id="boleto" required>
                                    <label for="boleto" style="margin-left: 10px; cursor: pointer;">
                                        <i class="fas fa-barcode fa-2x" style="vertical-align: middle; color: var(--ps-light-blue);"></i>
                                        <strong style="font-size: 1.2rem; margin-left: 15px;">Boleto Bancário</strong>
                                        <p style="margin: 10px 0 0 55px; color: rgba(255,255,255,0.7);">Vencimento em 3 dias úteis</p>
                                    </label>
                                </div>

                                <button type="submit" class="btn btn-ps5 btn-lg w-100 mt-4">
                                    <i class="fas fa-check-circle"></i> FINALIZAR PEDIDO
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-lg-4">
                    <!-- Resumo do Pedido -->
                    <div class="summary-box">
                        <h4 style="color: var(--ps-light-blue); margin-bottom: 20px;">
                            <i class="fas fa-receipt"></i> RESUMO DO PEDIDO
                        </h4>
                        
                        <div class="summary-item">
                            <span>Subtotal:</span>
                            <span><?php echo formatarPreco($subtotal); ?></span>
                        </div>
                        
                        <?php if($desconto > 0): ?>
                            <div class="summary-item" style="color: #28a745;">
                                <span><i class="fas fa-tag"></i> Desconto:</span>
                                <span>- <?php echo formatarPreco($desconto); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="summary-item">
                            <span>Frete:</span>
                            <span><?php echo formatarPreco($frete); ?></span>
                        </div>
                        
                        <div class="summary-total">
                            <span>TOTAL:</span>
                            <span><?php echo formatarPreco($total); ?></span>
                        </div>
                        
                        <div class="text-center mt-4" style="font-size: 0.9rem; opacity: 0.8;">
                            <i class="fas fa-lock"></i> Compra 100% segura
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function selecionarPagamento(metodo) {
            document.getElementById(metodo).checked = true;
            
            document.querySelectorAll('.payment-method').forEach(el => {
                el.classList.remove('selected');
            });
            
            document.getElementById(metodo).closest('.payment-method').classList.add('selected');
        }
    </script>
</body>
</html>