<?php
session_start();

// Manter o carrinho
$carrinho_temporario = isset($_SESSION['carrinho']) ? $_SESSION['carrinho'] : array();

// Destruir todas as variáveis de sessão
$_SESSION = array();

// Restaurar o carrinho
$_SESSION['carrinho'] = $carrinho_temporario;

// Destruir o cookie da sessão
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-42000, '/');
}

// Redirecionar para a página inicial
header('Location: index.php');
exit();
?>