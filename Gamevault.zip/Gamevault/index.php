<?php
require_once 'config.php';

// Buscar produtos em destaque
$sql_destaques = "SELECT p.*, c.nome as categoria_nome FROM products p 
                  INNER JOIN categories c ON p.categoria_id = c.id 
                  WHERE p.destaque = TRUE ORDER BY p.data_criacao DESC LIMIT 4";
$destaques = $conn->query($sql_destaques);

// Buscar categorias
$sql_categorias = "SELECT * FROM categories ORDER BY nome";
$categorias = $conn->query($sql_categorias);

// Filtros
$categoria_filtro = isset($_GET['categoria']) ? intval($_GET['categoria']) : 0;
$busca = isset($_GET['busca']) ? limparInput($_GET['busca']) : '';
$ordenacao = isset($_GET['ordem']) ? limparInput($_GET['ordem']) : 'recente';

// Construir query de produtos
$sql_produtos = "SELECT p.*, c.nome as categoria_nome FROM products p 
                 INNER JOIN categories c ON p.categoria_id = c.id WHERE 1=1";

if ($categoria_filtro > 0) {
    $sql_produtos .= " AND p.categoria_id = $categoria_filtro";
}

if (!empty($busca)) {
    $sql_produtos .= " AND (p.nome LIKE '%$busca%' OR p.descricao LIKE '%$busca%')";
}

// Ordenação
switch($ordenacao) {
    case 'preco_asc':
        $sql_produtos .= " ORDER BY p.preco ASC";
        break;
    case 'preco_desc':
        $sql_produtos .= " ORDER BY p.preco DESC";
        break;
    case 'nome':
        $sql_produtos .= " ORDER BY p.nome ASC";
        break;
    default:
        $sql_produtos .= " ORDER BY p.data_criacao DESC";
}

$produtos = $conn->query($sql_produtos);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameVault - Sua Loja de Games</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
            --ps-dark: #000000;
            --ps-gray: #1F1F1F;
            --ps-white: #FFFFFF;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: var(--ps-white);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(0, 0, 0, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 2px solid var(--ps-blue);
            box-shadow: 0 4px 30px rgba(0, 112, 204, 0.3);
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--ps-white) !important;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .navbar-brand i {
            color: var(--ps-light-blue);
        }
        
        .nav-link {
            color: var(--ps-white) !important;
            font-weight: 500;
            transition: all 0.3s;
            position: relative;
        }
        
        .nav-link:hover {
            color: var(--ps-light-blue) !important;
            transform: translateY(-2px);
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: var(--ps-light-blue);
            transition: all 0.3s;
            transform: translateX(-50%);
        }
        
        .nav-link:hover::after {
            width: 80%;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 25px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            background: linear-gradient(135deg, var(--ps-light-blue), var(--ps-blue));
        }
        
        .hero-section {
            padding: 80px 0;
            text-align: center;
            background: linear-gradient(180deg, rgba(0, 112, 204, 0.2) 0%, transparent 100%);
        }
        
        .hero-section h1 {
            font-size: 3.5rem;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 20px;
            text-shadow: 0 0 30px rgba(0, 112, 204, 0.8);
        }
        
        .search-bar {
            max-width: 600px;
            margin: 30px auto;
        }
        
        .search-bar input {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            border-radius: 50px 0 0 50px;
            padding: 15px 25px;
        }
        
        .search-bar input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .search-bar button {
            border-radius: 0 50px 50px 0;
        }
        
        .category-pills {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
            margin: 30px 0;
        }
        
        .category-pill {
            background: rgba(0, 67, 156, 0.5);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .category-pill:hover, .category-pill.active {
            background: var(--ps-blue);
            color: white;
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.5);
        }
        
        .product-card {
            background: rgba(31, 31, 31, 0.8);
            border: 2px solid transparent;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
            backdrop-filter: blur(10px);
            height: 100%;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
            border-color: var(--ps-light-blue);
            box-shadow: 0 10px 40px rgba(0, 112, 204, 0.5);
        }
        
        .product-image {
            height: 250px;
            background: linear-gradient(135deg, #1a1a2e, #16213e);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .product-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        
        .product-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--ps-light-blue);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .product-body {
            padding: 20px;
        }
        
        .product-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: white;
            min-height: 50px;
        }
        
        .product-category {
            color: var(--ps-light-blue);
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        
        .product-price {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--ps-light-blue);
            margin: 15px 0;
        }
        
        .footer {
            background: rgba(0, 0, 0, 0.95);
            padding: 40px 0 20px;
            margin-top: 80px;
            border-top: 2px solid var(--ps-blue);
        }
        
        .badge-destaque {
            background: linear-gradient(135deg, #FFD700, #FFA500);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-gamepad"></i> GAMEVAULT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="carrinho.php">
                            <i class="fas fa-shopping-cart"></i> Carrinho 
                            <?php if(contarItensCarrinho() > 0): ?>
                                <span class="badge bg-danger"><?php echo contarItensCarrinho(); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if(isLogado()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="minha-conta.php"><i class="fas fa-user"></i> Minha Conta</a>
                        </li>
                        <?php if(isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/index.php"><i class="fas fa-cog"></i> Admin</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registro.php"><i class="fas fa-user-plus"></i> Cadastro</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1><i class="fas fa-trophy"></i> BEM-VINDO AO GAMEVAULT</h1>
            <p class="lead">Os melhores jogos de todas as gerações em um só lugar</p>
            
            <!-- Barra de busca -->
            <form method="GET" action="index.php" class="search-bar">
                <div class="input-group">
                    <input type="text" name="busca" class="form-control" placeholder="Buscar jogos..." value="<?php echo htmlspecialchars($busca); ?>">
                    <button class="btn btn-ps5" type="submit"><i class="fas fa-search"></i> Buscar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Categorias -->
    <div class="container">
        <div class="category-pills">
            <a href="index.php" class="category-pill <?php echo $categoria_filtro == 0 ? 'active' : ''; ?>">
                <i class="fas fa-th"></i> Todos
            </a>
            <?php 
            $categorias->data_seek(0);
            while($cat = $categorias->fetch_assoc()): 
            ?>
                <a href="?categoria=<?php echo $cat['id']; ?>" class="category-pill <?php echo $categoria_filtro == $cat['id'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['nome']); ?>
                </a>
            <?php endwhile; ?>
        </div>

        <!-- Ordenação -->
        <div class="row mb-4">
            <div class="col-md-6 offset-md-6">
                <form method="GET" action="index.php">
                    <?php if($categoria_filtro > 0): ?>
                        <input type="hidden" name="categoria" value="<?php echo $categoria_filtro; ?>">
                    <?php endif; ?>
                    <?php if(!empty($busca)): ?>
                        <input type="hidden" name="busca" value="<?php echo htmlspecialchars($busca); ?>">
                    <?php endif; ?>
                    <select name="ordem" class="form-select" onchange="this.form.submit()" style="background: rgba(31, 31, 31, 0.8); color: white; border: 2px solid var(--ps-blue);">
                        <option value="recente" <?php echo $ordenacao == 'recente' ? 'selected' : ''; ?>>Mais Recentes</option>
                        <option value="preco_asc" <?php echo $ordenacao == 'preco_asc' ? 'selected' : ''; ?>>Menor Preço</option>
                        <option value="preco_desc" <?php echo $ordenacao == 'preco_desc' ? 'selected' : ''; ?>>Maior Preço</option>
                        <option value="nome" <?php echo $ordenacao == 'nome' ? 'selected' : ''; ?>>Nome (A-Z)</option>
                    </select>
                </form>
            </div>
        </div>

        <!-- Destaques -->
        <?php if($categoria_filtro == 0 && empty($busca)): ?>
        <h2 class="text-center mb-4 mt-5"><i class="fas fa-star"></i> JOGOS EM DESTAQUE</h2>
        <div class="row g-4 mb-5">
            <?php while($produto = $destaques->fetch_assoc()): ?>
                <div class="col-md-6 col-lg-3">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>" onerror="this.src='https://via.placeholder.com/300x300/1a1a2e/0070CC?text=<?php echo urlencode($produto['nome']); ?>'">
                            <span class="product-badge badge-destaque"><i class="fas fa-star"></i> DESTAQUE</span>
                        </div>
                        <div class="product-body">
                            <div class="product-category"><?php echo htmlspecialchars($produto['categoria_nome']); ?></div>
                            <h5 class="product-title"><?php echo htmlspecialchars($produto['nome']); ?></h5>
                            <div class="product-price"><?php echo formatarPreco($produto['preco']); ?></div>
                            <div class="d-grid gap-2">
                                <a href="produto.php?id=<?php echo $produto['id']; ?>" class="btn btn-ps5">
                                    <i class="fas fa-eye"></i> Ver Detalhes
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>

        <!-- Catálogo Completo -->
        <h2 class="text-center mb-4 mt-5"><i class="fas fa-gamepad"></i> CATÁLOGO</h2>
        <div class="row g-4 mb-5">
            <?php if($produtos->num_rows > 0): ?>
                <?php while($produto = $produtos->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-3">
                        <div class="product-card">
                            <div class="product-image">
                                <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>" onerror="this.src='https://via.placeholder.com/300x300/1a1a2e/0070CC?text=<?php echo urlencode($produto['nome']); ?>'">
                                <span class="product-badge"><?php echo htmlspecialchars($produto['categoria_nome']); ?></span>
                            </div>
                            <div class="product-body">
                                <h5 class="product-title"><?php echo htmlspecialchars($produto['nome']); ?></h5>
                                <div class="product-price"><?php echo formatarPreco($produto['preco']); ?></div>
                                <div class="d-grid gap-2">
                                    <a href="produto.php?id=<?php echo $produto['id']; ?>" class="btn btn-ps5">
                                        <i class="fas fa-shopping-cart"></i> Comprar
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle"></i> Nenhum produto encontrado.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><i class="fas fa-gamepad"></i> GAMEVAULT</h5>
                    <p>Sua loja especializada em jogos de todas as gerações.</p>
                </div>
                <div class="col-md-4">
                    <h5>Links Rápidos</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white text-decoration-none">Catálogo</a></li>
                        <li><a href="carrinho.php" class="text-white text-decoration-none">Carrinho</a></li>
                        <li><a href="minha-conta.php" class="text-white text-decoration-none">Minha Conta</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p><i class="fas fa-envelope"></i> contato@gamevault.com</p>
                    <p><i class="fas fa-phone"></i> (11) 98765-4321</p>
                </div>
            </div>
            <hr style="border-color: var(--ps-blue);">
            <p class="text-center mb-0">© 2025 GameVault. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>