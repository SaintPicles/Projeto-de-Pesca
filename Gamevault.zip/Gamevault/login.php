<?php
require_once 'config.php';

// Redirecionar se já estiver logado
if (isLogado()) {
    header('Location: index.php');
    exit();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = limparInput($_POST['email']);
    $senha = $_POST['senha'];
    
    if (empty($email) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } else {
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            
            // Verificar senha
            if (password_verify($senha, $usuario['senha'])) {
                // Login bem-sucedido
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_tipo'] = $usuario['tipo'];
                
                // Redirecionar para checkout se havia tentativa de compra
                if (isset($_SESSION['redirect_after_login'])) {
                    $redirect = $_SESSION['redirect_after_login'];
                    unset($_SESSION['redirect_after_login']);
                    header('Location: ' . $redirect);
                } else {
                    header('Location: index.php');
                }
                exit();
            } else {
                $erro = 'Senha incorreta.';
            }
        } else {
            $erro = 'E-mail não cadastrado.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - GameVault</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ps-blue: #00439C;
            --ps-light-blue: #0070CC;
        }
        
        body {
            background: linear-gradient(135deg, #000428 0%, #004e92 100%);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: rgba(31, 31, 31, 0.95);
            border: 2px solid var(--ps-blue);
            border-radius: 20px;
            padding: 50px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 10px 50px rgba(0, 112, 204, 0.5);
            backdrop-filter: blur(10px);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .login-header h1 {
            font-size: 2.5rem;
            font-weight: 800;
            text-transform: uppercase;
            color: white;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(0, 112, 204, 0.8);
        }
        
        .login-header .logo {
            font-size: 4rem;
            color: var(--ps-light-blue);
            margin-bottom: 20px;
        }
        
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--ps-blue);
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 1rem;
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--ps-light-blue);
            color: white;
            box-shadow: 0 0 15px rgba(0, 112, 204, 0.5);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .form-label {
            font-weight: 600;
            color: var(--ps-light-blue);
            margin-bottom: 8px;
        }
        
        .btn-ps5 {
            background: linear-gradient(135deg, var(--ps-blue), var(--ps-light-blue));
            border: none;
            color: white;
            font-weight: 700;
            padding: 15px;
            border-radius: 10px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 112, 204, 0.4);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn-ps5:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 112, 204, 0.6);
            color: white;
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.2);
            border: 2px solid #dc3545;
            color: #ff6b6b;
            border-radius: 10px;
        }
        
        .divider {
            text-align: center;
            margin: 30px 0;
            position: relative;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: rgba(255, 255, 255, 0.2);
        }
        
        .divider span {
            background: rgba(31, 31, 31, 0.95);
            padding: 0 15px;
            position: relative;
            color: rgba(255, 255, 255, 0.6);
        }
        
        .link-light {
            color: var(--ps-light-blue) !important;
            text-decoration: none;
            font-weight: 600;
        }
        
        .link-light:hover {
            color: white !important;
            text-decoration: underline;
        }
        
        .back-home {
            position: absolute;
            top: 30px;
            left: 30px;
        }
        
        .back-home a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .back-home a:hover {
            color: var(--ps-light-blue);
        }
    </style>
</head>
<body>
    <div class="back-home">
        <a href="index.php">
            <i class="fas fa-arrow-left"></i> Voltar à Loja
        </a>
    </div>

    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-gamepad"></i>
            </div>
            <h1>LOGIN</h1>
            <p style="color: rgba(255, 255, 255, 0.7);">Acesse sua conta GameVault</p>
        </div>

        <?php if (!empty($erro)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $erro; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">
                    <i class="fas fa-envelope"></i> E-mail
                </label>
                <input type="email" class="form-control" id="email" name="email" 
                       placeholder="seu@email.com" required>
            </div>

            <div class="mb-4">
                <label for="senha" class="form-label">
                    <i class="fas fa-lock"></i> Senha
                </label>
                <input type="password" class="form-control" id="senha" name="senha" 
                       placeholder="Digite sua senha" required>
            </div>

            <button type="submit" class="btn btn-ps5 w-100">
                <i class="fas fa-sign-in-alt"></i> ENTRAR
            </button>
        </form>

        <div class="divider">
            <span>OU</span>
        </div>

        <div class="text-center">
            <p style="color: rgba(255, 255, 255, 0.7);">
                Não tem uma conta?
            </p>
            <a href="registro.php" class="btn btn-outline-light w-100">
                <i class="fas fa-user-plus"></i> CRIAR CONTA
            </a>
        </div>

        <div class="text-center mt-4">
            <small style="color: rgba(255, 255, 255, 0.5);">
                <i class="fas fa-lock"></i> Seus dados estão protegidos
            </small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>