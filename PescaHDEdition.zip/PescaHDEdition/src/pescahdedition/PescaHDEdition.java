/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pescahdedition;

import javax.swing.JOptionPane;

/**
 *
 * @author lucca.bcdomingues
 */
public class PescaHDEdition {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // String nome = JOptionPane.showInputDialog(null,"Digite seu nome");
       // JOptionPane.showMessageDialog(null,"Eae Seu "+ nome);
       double numero = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite um numero de peixes já pescados"));
       double numero2 = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite um numero de Espécies de peixes já pescados"));
       double multiplicação = numero * numero2;
       JOptionPane.showMessageDialog(null,"Já pescou " + multiplicação + " peixes altos peixes");
    }
    
}
