/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package base.da.pesca;

import javax.swing.JOptionPane;

/**
 *
 * @author lucca.bcdomingues
 */
public class BaseDaPesca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JOptionPane.showMessageDialog(null,"Proibido qualquer assunto que não seja pesca");
        JOptionPane.showMessageDialog(null,"A pesca sempre vai ser a primeira opção");
    }
    
}
