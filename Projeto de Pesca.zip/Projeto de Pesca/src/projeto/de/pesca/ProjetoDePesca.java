/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto.de.pesca;

/**
 *
 * @author lucca.bcdomingues
 */
public class ProjetoDePesca {
    public static void frase(){
        System.out.println("Imprimindo a pesca");
        
    }
    public static void flor(){
        System.out.println("Abra a flor");
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frase();
        flor();
        flor();
        
        
    }
    
}
