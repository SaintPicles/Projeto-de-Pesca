/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pesca.de.novo;

import javax.swing.JOptionPane;

/**
 *
 * @author lucca.bcdomingues
 */
public class PescaDeNovo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // TODO code application logic here
       //JOptionPane.showMessageDialog(null,"A pesca é Inevitavel");
       // JOptionPane.showInputDialog(null,"Insira seu nome de Pescador");
       //JOptionPane.showConfirmDialog(null,"Vai se juntar a Pesca ?");
       
       String nome = JOptionPane.showInputDialog(null,"Insira seu nome de Pescador");
       JOptionPane.showMessageDialog(null,"Seja bem vindo a Pesca "+ nome + "!");
       
       String idade = JOptionPane.showInputDialog(null,"Insira sua idade");
       JOptionPane.showMessageDialog(null,nome +" " +idade + " anos");
       
       
    }
    
}
